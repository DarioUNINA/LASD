
void testFullExercise1() {
}
