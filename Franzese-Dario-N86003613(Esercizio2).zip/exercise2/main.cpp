
#include "zlasdtest/test.hpp"

#include "zmytest/test.hpp"

/* ************************************************************************** */

#include <iostream>
#include <exception>

/* ************************************************************************** */

int main() {
  std::cout << "Lasd Libraries 2022" << std::endl;
  Menu();
  return 0;
}
